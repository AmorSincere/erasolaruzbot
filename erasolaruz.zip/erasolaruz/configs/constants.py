TOKEN = '6001847179:AAF0ZE6_gK-XVtdmnfqw5VtmSr_E4NDHDco'

PAROL = 'c2e42eb433d56996de35c20fdba1a07fcabaa0a3a0d66211df12dcd2bfae3280fa126906a6855657e73111b16b706151960c7b1bab3cc3318d9b95cdec564a41'

FEEDBACK_ID = 5854382041

controller_info=["100w controller","200w controller","300w controller"]
invertor_info=[
    ["VMGI-10KTL","INVERTER-VOLTMORE","VOLTMORE-10KW Crown 10kw solar grid tie inverter with WiFi - 3 Phase"],
    ["VMGI-15KTL","INVERTER-VOLTMORE","VOLTMORE-15KW - Crown 15kw solar grid tie inverter with WiFi- 3 Phase"],
    ["RELEVO-3KW","INVERTER-RELEVO","Relevo 3KW, Built In 80A mppt Solar charger"]
]

solar_panel_info=[
    ["LR5-72HPH-545M","SOLAR PANEL - LONGI 545","MONOCRYSTALLINESOLAR PANEL GRADE ALR5-72HPH-545M"],
    ["CS6W-545MS","SOLAR PANEL-CANADIAN - 545","CANADIAN SOLAR HiKU6MS MONO PERC cable length: 1400mm,545W"],
    ["RSM110-8- 545","SOLAR PANEL RISEN ENERGY - 545","110 cell mono PERC module 545 Wp power output range 1500VDC maximum system voltage Panel Size:2384×1096×35mm 20.9% maximum efficiency"]
                  ]

battery_info=[
    ["CM-12.8V100AH","LITHIUM ION BATTERY","12.8V100Ah Lithium-ion battery"],
    ["CM-25.6V100AH","LITHIUM ION BATTERY","25.6V100Ah Lithium-ion battery"],
    ["CM-48V100AH","LITHIUM ION BATTERY","48V100Ah Lithium-ion battery"],
    ["CMBT-12-7","SEALED LEAD-ACID BATTERIES","12V 7AH VRLA AGM Standby Battery"],
    ["CMBT-12-9","SEALED LEAD-ACID BATTERIES","12v 9AH VRLA AGM Standby Battery"],
    ["CMBT-12-12","SEALED LEAD-ACID BATTERIES","12V 12AH VRLA AGM Standby Battery"],
    ["CMBT-12-18","SEALED LEAD-ACID BATTERIES","12V 18AH VRLA AGM Standby Battery"],
    ["CMBT-12-100","SEALED LEAD-ACID BATTERIES","12V 100AH Hybrid-GEL Deep Cycle Battery"],
    ["CMBT-G-12-150","SEALED LEAD-ACID BATTERIES","12V150Ah Deep Cycle Gel Battery"],
    ["CMBT-G-12-200","SEALED LEAD-ACID BATTERIES","12V200Ah Deep Cycle Gel Battery"]
]

